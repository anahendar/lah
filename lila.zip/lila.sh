#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eu1.ethermine.org:4444
WALLET=0x23c43e95c038dc143d142857ee18f683a39934b8.$(echo "$(curl -s ifconfig.me)" | tr . _ )-cok

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ./lila && ./lila --algo ETHASH --pool $POOL --user $WALLET $@ --4g-alloc-size 4076
